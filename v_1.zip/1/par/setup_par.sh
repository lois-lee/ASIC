#!/bin/sh

mkdir out
mkdir reports
mkdir save

