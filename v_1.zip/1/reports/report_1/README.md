These are the reports from the nonfunctional block from 11/01
